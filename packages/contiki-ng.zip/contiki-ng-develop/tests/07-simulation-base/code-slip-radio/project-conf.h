#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_

#define RPL_CONF_DAO_ACK		1

#endif /* PROJECT_CONF_H_ */
